/* 
 * File: NumberToChar.c  
 * Revision history: 
 */

#include "NumberToChar.h"
#include <stdio.h>

// Función auxiliar para contar la cantidad de dígitos de un número entero
int count_digits(int number) {
    int count = 0;
    while (number != 0) {
        number /= 10;
        count++;
    }
    return count;
}

void float_to_char_array(float number, char* char_array, int max_length) {
    int int_part = (int)number;            // Parte entera del número
    float decimal_part = number - int_part; // Parte decimal del número
    int int_digits;
      
    if (number < 1) {
        // Caso especial: número menor que 1 (sin parte entera)
        char_array[0] = '0';
        char_array[1] = '.';
        int_digits = 2; // Se establece a 2 para considerar los caracteres '0' y '.'
        number *= 10;    
        
        // Convertir la parte decimal a caracteres
            int decimal_digits = 0;
            while (decimal_digits < 2 && int_digits < max_length - 1) {
                decimal_part *= 10;
                int decimal_digit = (int)decimal_part;
                char_array[int_digits] = '0' + decimal_digit;
                decimal_part -= decimal_digit;
                int_digits++;
                decimal_digits++;
            }
    
    } else {
        // Convertir la parte entera a caracteres
        int_digits = count_digits(int_part);

        if (int_digits >= max_length) {
            // Manejo de error si el resultado excede el tamaño máximo del arreglo
            printf("Error: El tamaño del arreglo de caracteres no es suficiente.\n");
            return;
        }

        // Convertir la parte entera a caracteres
        int i;
        for (i = 0; i < int_digits; i++) {
            char_array[i] = '0' + (int_part % 10);
            int_part /= 10;
        }

        // Invertir los caracteres para que queden en el orden correcto
        int left = 0;
        int right = int_digits - 1;
        while (left < right) {
            char temp = char_array[left];
            char_array[left] = char_array[right];
            char_array[right] = temp;
            left++;
            right--;
        }

        // Si hay parte decimal, agregar el punto y los dígitos decimales
        if (number != (int)number) {
            if (int_digits + 1 >= max_length) {
                // Manejo de error si el resultado excede el tamaño máximo del arreglo
                printf("Error: El tamaño del arreglo de caracteres no es suficiente.\n");
                return;
            }
            char_array[int_digits] = '.';
            int_digits++;

            // Convertir la parte decimal a caracteres
            int decimal_digits = 0;
            while (decimal_digits < 2 && int_digits < max_length - 1) {
                decimal_part *= 10;
                int decimal_digit = (int)decimal_part;
                char_array[int_digits] = '0' + decimal_digit;
                decimal_part -= decimal_digit;
                int_digits++;
                decimal_digits++;
            }
        }
    } 
      
    // Agregar el carácter nulo de terminación
    if (int_digits < max_length) {
        char_array[int_digits] = '\0';
    } else {
        // Manejo de error si el resultado excede el tamaño máximo del arreglo
        printf("Error: El tamaño del arreglo de caracteres no es suficiente.\n");
        return;
    }
}