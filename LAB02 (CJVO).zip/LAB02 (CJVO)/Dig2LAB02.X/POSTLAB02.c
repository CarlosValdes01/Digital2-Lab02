/* 
 * Archivo: Dig2LAB02.c
 * Dispositivo: PIC16F887
 * Autor: Carlos Julio Valdés Oajaca
 * Compilador: XC8, MPLABX v6.05
 
 * Programa: Uso de pantalla LCD
 * Hardware: potenciometro y LCD

 * Creado: 24 de julio, 2023
 * Última modificación: 25 de julio, 2023
 */

//************************************************************************************
// PALABRAS DE CONFIGURACION
//************************************************************************************
// PIC16F887 Configuration Bit Settings
// 'C' source line config statements
// CONFIG1
#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (INTOSCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, I/O function on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)
// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
//************************************************************************************
//************************************************************************************
// LIBRERIAS
//************************************************************************************
#include <pic16f887.h>
#include <xc.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "ConfgADC1.h"
#include "LCD4bits.h"
#include "NumberToChar.h"
#include "ConfgUART.h"

#define _XTAL_FREQ 8000000 //8MHz
//************************************************************************************
//************************************************************************************
// PROTOTIPOS DE FUNCIONES
//************************************************************************************
void setup(void);
//************************************************************************************
//************************************************************************************
// VARIABLES GLOBALES
//************************************************************************************
uint8_t channel = 0x05;
char s[20];
float ADC_volts;
int valor_ADC;

uint8_t flag;
uint8_t baudrate = 51;
char RX;
char cont[20];
char POT_char[];
//************************************************************************************
//************************************************************************************
// DEFINIR CONSTANTES
//************************************************************************************


//************************************************************************************
//************************************************************************************
// INTERRUPCIONES
//************************************************************************************
void  __interrupt() isr(void)
{
    if(PIR1bits.RCIF)     //Datos recibidos?
    {    
        RX =RCREG;
    }
    
    if(PIR1bits.ADIF == 1) //INTERRUPCION ADC
    {
       valor_ADC = adc_read();
       //PORTA++;
       PIR1bits.ADIF = 0;
    }
///////////////////////////////////////////////////////    

}

//************************************************************************************
//************************************************************************************
// FUNCION PRINCIPAL
//************************************************************************************
void main(void){
    adc_init(channel);
    unsigned int a;
    TRISD = 0;
    TRISC = 0;
    Lcd_Init();
    UART_RX_CONFIG(baudrate);
    UART_TX_CONFIG(baudrate);
    setup();
    ADCON0bits.GO =1;
    
    while(1){ //Loop infinito       
        
        if (ADCON0bits.GO ==0){
            
            __delay_us(1000);
            ADCON0bits.GO =1;
        }
     ADC_volts = MAP(valor_ADC, 0, 255, 0, 5);
    
     Lcd_Clear();
     Lcd_Set_Cursor(1,1);
     Lcd_Write_String("POT:");
     float_to_char_array(ADC_volts, s, sizeof(s));
     Lcd_Set_Cursor(2,1);
     Lcd_Write_String(s);
     Lcd_Write_Char('V');
     
     Lcd_Set_Cursor(1,8);
     Lcd_Write_String("CONT:");
     float_to_char_array(PORTA, cont, sizeof(cont));
     Lcd_Set_Cursor(2,8);
     Lcd_Write_String(cont);
     
     UART_WRITE("\r ---------------------------------------------- \r");  // UART print
     UART_WRITE("\r Sea bienvenido, que accion desea realizar? \r\n");
     UART_WRITE(" 1) Leer Potenciometro \r\n");
     UART_WRITE(" 2) Aumentar contador \r\n");
     UART_WRITE("\r ----------------------------------------------  \r");
     flag = 1;
     
     while(flag)
        {
         while(PIR1bits.RCIF == 0); //Esperar a recibir dato
         
           a = RX;
           
           switch(a){ 
            case('1'):
                UART_WRITE("\r El valor del potenciometro es: \r\n");
                itoa(POT_char,ADRESH,10);;
                UART_READ(POT_char);
                UART_WRITE("\r Listo \r\n");   
                flag = 0;
                break;
                
            case('2'):
                UART_WRITE("\r Ingrese un caracter para incrementar o decrementar el contador:  \r");
                while(PIR1bits.RCIF == 0); //Esperar a recibir dato
                
                if (RX == '+')        //aumentar contador
                    PORTA++;
                else if (RX == '-')  //decrementar contador
                    PORTA--;
                
                //UART_READ(RX);             //Mostrar el caracter en la pantalla
                UART_WRITE("\r Listo \r\n");   
                flag = 0;
                break;
            
            default:    
                UART_WRITE(" Error \r\n");
           }
        }     
        
    }
}

//************************************************************************************
//************************************************************************************
// FUNCIONES
//************************************************************************************
void setup(void){
    //configuracion de pines y puertos    
    ANSEL= 0b00100000;  //configurar los pines de los POT
    ANSELH= 0; //configura los pines de portB como digital
    
    TRISA = 0; // Configura el portA como salida
    TRISEbits.TRISE0 = 1;//Configurar entradas de los POT
    
    PORTA = 0;
    PORTC = 0;
    PORTD = 0;
    PORTE = 0;
    
    //configuracion oscilador
    OSCCONbits.IRCF = 0b0111; //8MHz
    OSCCONbits.SCS = 1;       //Utilizar el reloj interno
    
    INTCONbits.PEIE = 1; //Habilitar interrupciones perifericas
    INTCONbits.GIE = 1; // Habilita interrupciones generales
}

//************************************************************************************